# CardGradientBorder

A Pen created on CodePen.io. Original URL: [https://codepen.io/rospl_css/pen/MWGZEqd](https://codepen.io/rospl_css/pen/MWGZEqd).

