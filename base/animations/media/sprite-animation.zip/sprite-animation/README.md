# Sprite Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/rospl_css/pen/JjZGvbJ](https://codepen.io/rospl_css/pen/JjZGvbJ).

