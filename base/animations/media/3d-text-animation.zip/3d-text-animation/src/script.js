const canvas = document.querySelector('#confetti')
    const btn = document.querySelector('.btn')
    const jsConfetti = new JSConfetti({
      canvas
    });

    btn.addEventListener('click', () => {
      jsConfetti.addConfetti({
        confettiColors: [
          '#892AB8', '#EA4C89', '#FFFF04', '#4AF2FD'
        ],
        confettiRadius: 3,
        confettiNumber: 250
      });
    });