# Reverse text animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/rospl_css/pen/XWYXYbV](https://codepen.io/rospl_css/pen/XWYXYbV).

