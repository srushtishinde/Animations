# Glass Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/rospl_css/pen/VwdexLr](https://codepen.io/rospl_css/pen/VwdexLr).

