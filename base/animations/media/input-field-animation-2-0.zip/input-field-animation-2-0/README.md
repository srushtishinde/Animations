# Input Field Animation 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/rospl_css/pen/dyKGKmB](https://codepen.io/rospl_css/pen/dyKGKmB).

