# CustomRadioAnimation

A Pen created on CodePen.io. Original URL: [https://codepen.io/rospl_css/pen/bGMOoZm](https://codepen.io/rospl_css/pen/bGMOoZm).

